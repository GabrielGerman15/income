package trabajo_practico;

public record invalidUserDataException() {

	public String getMessage() {
		// TODO Auto-generated method stub
		return null;
	}

}
