package trabajo_practico;

public class EmployeeBuilder {

	public Object setName(String name) {
		return null;
	}
	public Object setApellido(String name) {
		return null;
	}
	public Object setCuil(String cuil) {
		return null;
	}
	public Object setEmployeeNumber(String employeeNumber) {
		return null;
	}
	public Object setPhone(String phone) {
		return null;
	}
	public Object setPhoto(String photo) {
		return null;
	}
	public Object setEmailAdress(String emailAdress) {
		return null;
	}
	public Object setAdress(String adress) {
		return null;
	}
	public Object setLocality(String locality) {
		return null;
	}
	public Object setProvince(String Province) {
		return null;
	}
	public Object setPostalCode(String postalCode) {
		return null;
	}
	public Employee createEmployee() {
		return null;
	}
}

